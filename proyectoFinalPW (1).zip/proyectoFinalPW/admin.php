<!DOCTYPE html>
<html>
<head>
    <title>Panel de Administración - Transporte de Autobuses</title>
    <link rel="stylesheet" type="text/css" href="./css/stylesAdministrador.css"> 
</head>
<body>
    <header>
        <h1>Panel de Administración</h1>
        <nav>
            <ul>
                <li><a href="listaUsuarios.php">Lista de Usuarios</a></li>
                <li><a href="listaViajes.php">Destinos Activos</a></li>
                <!-- Agrega enlaces a otras áreas de gestión -->
                <li><a href="logout.php">Cerrar sesión</a></li>
            </ul>
        </nav>
    </header>
    <main>
        <h2>Información de Viajes en Autobús</h2>

        <!-- Aquí puedes mostrar información relevante, como una lista de viajes programados, estadísticas, etc. -->
        <!-- Puedes personalizar esta sección según tus necesidades -->

        <div class="travel-info">
            <h3>Viajes Programados</h3>
            <ul>
                <li><strong>Origen:</strong> La Laguna - <strong>Destino:</strong> Acapulco</li>
                <li><strong>Origen:</strong> La Laguna - <strong>Destino:</strong> Los Cabos</li>
                <li><strong>Origen:</strong> La Laguna - <strong>Destino:</strong> Ciudad de Mexico</li>
                <!-- Puedes generar dinámicamente esta lista desde PHP si es necesario -->
            </ul>
        </div>

        <!-- Otras secciones y estadísticas se pueden agregar aquí -->

    </main>
    <footer>
        <p>&copy; <?php echo date("Y"); ?> Transporte de Autobuses</p>
    </footer>
</body>
</html>