
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Registrarse</title>
    <link rel="stylesheet" href="./css/stylesRegistro.css">
    
</head>
<body>
    <h1 class="title2">Autobuses Laguneros</h1>
    <input type="button" class="button3" onclick="history.back()" value="Regresar">
   <div class="container">
    <div class="title">Registro</div>
        <form method="post">
            <div class="user-details">
            <div class="input-box">
                    <span class="details">Username</span>
                    <input type="text" name="username" placeholder="Ingresa tu nombre de usuario" required>
                </div>
                <div class="input-box">
                    <span class="details">Correo Electronico</span>
                    <input type="text" name="correo" placeholder="Ingresa tu correo" required>
                </div>
                <div class="input-box">
                    <span class="details">Telefono</span>
                    <input type="text" name="telefono" placeholder="Ingresa tu telefono" required>
                </div>
                <div class="input-box">
                    <span class="details">Contraseña</span>
                    <input type="text" name="contra" placeholder="Ingresa tu contraseña" required>
                </div>
                
            </div>
            <div class="button">
                <input type="submit" name="register" value="Registrate">
                <div class="link-right">
				<a href="listaUsuarios.php" class="link-primary">View</a>
			</div>
            </div>
            
        </form>
        <?php
        include("registrar.php");
        ?>
        
   </div>
  
</body>
</html>