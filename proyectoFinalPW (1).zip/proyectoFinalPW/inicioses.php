<!DOCTYPE html>
<html>
<head>
	<title>LOGIN</title>
    <link rel="stylesheet" href="./css/stylesLogin.css">
</head>
<body>
     <form action="inicioses.php" method="post">	 
     	<h2>LOGIN</h2>
		     	
     	<label>User Name</label>
     	<input type="text" name="uname" placeholder="User Name"><br>

     	<label>Password</label>
     	<input type="password" name="password" placeholder="Password"><br>
		 
     	<button type="submit">Login</button>
		<a href='registro.php' type="button">Registrarme</a>
     </form>
</body>
</html>
<?php
    require 'database.php';

    session_start();

    if(isset($_GET['cerrar_sesion'])){
        session_unset();

        session_destroy();
    }

    if(isset($_SESSION['rol_id'])){
        switch($_SESSION['rol_id']){
            case '1':
                header('location: admin.php');
            break;

            case '2':
            header('location: index2.php');
            break;

            default:
        }
    }

    if(isset($_POST['uname']) && isset($_POST['password'])){
        $username = $_POST['uname'];
        $password = $_POST['password'];

        
        $db = new Database();
        $query = $db->connect()->prepare('SELECT*FROM personas WHERE usuario = :uname AND contra = :password');
        $query->execute(['uname' => $username, 'password' => $password]);

		
        $row = $query->fetch(PDO::FETCH_NUM);
        if($row == true){
            // validar rol
            $rol = $row[5];
            $_SESSION['rol_id'] = $rol;

            switch($_SESSION['rol_id']){
                case '1':
                    header('location: admin.php');
                break;
    
                case '2':
                header('location: index2.php');
                break;
    
                default:
            }
        }else{
            // no existe el usuario
            ?>
            <h3 class="success" id="successMessage">El usuario o la contraseña son incorrectos</h3>
            <?php
            }
        }
    
    

?>
