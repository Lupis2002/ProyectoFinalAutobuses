<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Autobuses Laguneros</title>
    <link rel="stylesheet" href="./css/style.css">
    <link rel="stylesheet" href="./css/swiper-bundle.min.css">
</head>
<body>
    
    <header class="header">

        <div class="menu container">
            <a href="#" class="logo">Autobuses Laguneros</a>
            <input type="checkbox" id="menu">
            <label for="menu">
                <img src="./images/menu.png" class="menu-icono" alt="">
            </label>

            <nav class="navbar">
                <ul>
                    <li><a href='inicioses.php'>Mi cuenta</a></li>                    
                    <li><a href="./html/empleo.html">Bolsa de Trabajo</a></li>
                    <li><a href="#destinos">Destinos</a></li>
                    <li><a href="./html/nuestrogpo.html">Nosotros</a></li>
                </ul>
            </nav>

        </div>

        <div class="headser-content container">
            <div class="header-txt">
                <h1>Ahora es mas facil <span> viajar</span> a tu destino favorito</h1>
                <p>
                    Reserva tu viaje con nostros y vive de una experiencia de primera clase.
                </p>
                <a href="#" class="btn-1">Informacion</a>
            </div>
        </div>

    </header>

    <section class="about container">   
        <div class="about-img">
            <img src="./images/b1.jpg" alt="">
            <img src="./images/b2.jpg" alt="">
        </div>

        <div class="about-txt">
            <h2>Viajar con nosotros es la <span> mejor</span> experiencia</h2>
            <p>
                Todos los destinos turisticos estan con nosotros.
            </p>
            <a href="" class="btn-1">Informacion</a>
        </div>
    </section>

    <main class="products container">
        <a name="destinos"></a>
        <h2>Nuestros <span>destinos</span></h2>
        <div class="slide-container swiper">
            <div class="slide-content">
                <div class="card-wrapper swiper-wrapper">
    
                    <div class="card swiper-slide">
                        <div class="image-content">
                            <span class="overlay"></span>
    
                            <div class="card-image">
                                    <img src="./images/1.jpg" alt="" class="card-image">
                            </div>
                        </div>
    
                        <div class="card-content">
                            <h2 class="name">Chichen Itza</h2>
                            <P class="description"> Visita y queda fascinado con una de las 7 maravillas del mundo...</P>
                            <a href="regPasajero.php" class="btn-2">Reservar</a>
                        </div>
                    </div>
       
                    <div class="card swiper-slide">
                        <div class="image-content">
                            <span class="overlay"></span>
    
                            <div class="card-image">
                                    <img src="./images/2.jpg" alt="" class="card-image">
                            </div>
                        </div>
    
                        <div class="card-content">
                            <h2 class="name">Los Cabos</h2>
                            <P class="description">Sumergete y disfruta de unas lindas vaciones en familia...</P>
                            <a href="regPasajero2.php" class="btn-2">Reservar</a>
                        </div>
                    </div>

                    <div class="card swiper-slide">
                        <div class="image-content">
                            <span class="overlay"></span>
    
                            <div class="card-image">
                                    <img src="./images/3.jpg" alt="" class="card-image">
                            </div>
                        </div>
    
                        <div class="card-content">
                            <h2 class="name">Ciudad de Mexico</h2>
                            <P class="description">Visita todos los centros turisticos que brinda la capital...</P>
                            <a href="regPasajero3.php" class="btn-2">Reservar</a>
                        </div>
                    </div>


                    <div class="card swiper-slide">
                        <div class="image-content">
                            <span class="overlay"></span>
    
                            <div class="card-image">
                                    <img src="./images/4.jpg" alt="" class="card-image">
                            </div>
                        </div>
    
                        <div class="card-content">
                            <h2 class="name">Mazatlan</h2>
                            <P class="description">Vive un fin de semana espectacular en la isla de la Piedra...</P>
                            <a href="regPasajero.html" class="btn-2">Reservar</a>
                        </div>
                    </div>

                    <div class="card swiper-slide">
                        <div class="image-content">
                            <span class="overlay"></span>
    
                            <div class="card-image">
                                    <img src="./images/5.jpg" alt="" class="card-image">
                            </div>
                        </div>
    
                        <div class="card-content">
                            <h2 class="name">Guadalajara</h2>
                            <P class="description">Visita la ciudad mas importante de Jalisco y dislumbrate con su belleza...</P>
                            <a href="regPasajero.html" class="btn-2">Reservar</a>
                        </div>
                    </div>


                    <div class="card swiper-slide">
                        <div class="image-content">
                            <span class="overlay"></span>
    
                            <div class="card-image">
                                    <img src="./images/6.jpg" alt="" class="card-image">
                            </div>
                        </div>
    
                        <div class="card-content">
                            <h2 class="name">Monterrey</h2>
                            <P class="description">Conoce una de las ciudades mas importante de nuestro pais...</P>
                            <a href="regPasajero.html" class="btn-2">Reservar</a>
                        </div>
                    </div>


                    <div class="card swiper-slide">
                        <div class="image-content">
                            <span class="overlay"></span>
    
                            <div class="card-image">
                                    <img src="./images/7.jpg" alt="" class="card-image">
                            </div>
                        </div>
    
                        <div class="card-content">
                            <h2 class="name">Cancun</h2>
                            <P class="description">Vive de una semana fascinante con tu familia en aguas cristalinas...</P>
                            <a href="regPasajero.html" class="btn-2">Reservar</a>
                        </div>
                    </div>


                    <div class="card swiper-slide">
                        <div class="image-content">
                            <span class="overlay"></span>
    
                            <div class="card-image">
                                    <img src="./images/8.jpg" alt="" class="card-image">
                            </div>
                        </div>
    
                        <div class="card-content">
                            <h2 class="name">Veracruz</h2>
                            <P class="description">Visita uno de los puertos mas turisticos de nuestro pais...</P>
                            <a href="regPasajero.html" class="btn-2">Reservar</a>
                        </div>
                    </div>


                    <div class="card swiper-slide">
                        <div class="image-content">
                            <span class="overlay"></span>
    
                            <div class="card-image">
                                    <img src="./images/9.jpg" alt="" class="card-image">
                            </div>
                        </div>
    
                        <div class="card-content">
                            <h2 class="name">Chihuahua</h2>
                            <P class="description">Deslumbrate con una de las ciudades mas bonitas en nuestro pais...</P>
                            <a href="regPasajero.html" class="btn-2">Reservar</a>
                        </div>
                    </div>


                    <div class="card swiper-slide">
                        <div class="image-content">
                            <span class="overlay"></span>
    
                            <div class="card-image">
                                    <img src="./images/guanajuato.jpg" alt="" class="card-image">
                            </div>
                        </div>
    
                        <div class="card-content">
                            <h2 class="name">Guanajuato</h2>
                            <P class="description"> Visita una de las ciudades coloniales mas bonitas de nuestro pais...</P>
                            <a href="regPasajero.html" class="btn-2">Reservar</a>
                        </div>
                    </div>


                    <div class="card swiper-slide">
                        <div class="image-content">
                            <span class="overlay"></span>
    
                            <div class="card-image">
                                    <img src="./images/acapulco.jpg" alt="" class="card-image">
                            </div>
                        </div>
    
                        <div class="card-content">
                            <h2 class="name">Acapulco</h2>
                            <P class="description">Visita una de las playas mas visitadas de nuestro pais...</P>
                            <a href="regPasajero.html" class="btn-2">Reservar</a>
                        </div>
                    </div>

                    <div class="card swiper-slide">
                        <div class="image-content">
                            <span class="overlay"></span>
    
                            <div class="card-image">
                                    <img src="./images/chiapas.jpg" alt="" class="card-image">
                            </div>
                        </div>
    
                        <div class="card-content">
                            <h2 class="name">Chiapas</h2>
                            <P class="description">Visita y recorre en lancha el Cañon del Sumidero...</P>
                            <a href="regPasajero.html" class="btn-2">Reservar</a>
                        </div>
                    </div>


                    <div class="card swiper-slide">
                        <div class="image-content">
                            <span class="overlay"></span>
    
                            <div class="card-image">
                                    <img src="./images/tijuana.jpg" alt="" class="card-image">
                            </div>
                        </div>
    
                        <div class="card-content">
                            <h2 class="name">Tijuana</h2>
                            <P class="description"> Visita la ciudad mas divertida del mundo mundial</P>
                            <a href="regPasajero.html" class="btn-2">Reservar</a>
                        </div>
                    </div>


                    <div class="card swiper-slide">
                        <div class="image-content">
                            <span class="overlay"></span>
    
                            <div class="card-image">
                                    <img src="./images/juarez.jpg" alt="" class="card-image">
                            </div>
                        </div>
    
                        <div class="card-content">
                            <h2 class="name">Ciudad Juarez</h2>
                            <P class="description">  Visita una de las fronteras mas famosas de México</P>
                            <a href="regPasajero.html" class="btn-2">Reservar</a>
                        </div>
                    </div>


                    <div class="card swiper-slide">
                        <div class="image-content">
                            <span class="overlay"></span>
    
                            <div class="card-image">
                                    <img src="./images/torreon.jpg" alt="" class="card-image">
                            </div>
                        </div>
    
                        <div class="card-content">
                            <h2 class="name">Torreon</h2>
                            <P class="description"> Ven y pasa unas increíbles vacaciones con toda la familia</P>
                            <a href="regPasajero.html" class="btn-2">Reservar</a>
                        </div>
                    </div>

                        
                </div>
        </div>
        <div class="swiper-button-next swiper-navBtn"></div>
                        <div class="swiper-button-prev swiper-navBtn"></div>
                        <div class="swiper-scrollbar swiper-navBtn"></div>
                        <div class="swiper-pagination"></div></div>
                        <script src="./js/_swiper-bundle.min.js"></script>
                        <script src="./js/javaCarrusel.js"></script>
        
    </main>
         


    


    <section class="information">
        
        <div class="information-content container">
            <div class="information-1"></div>
            <div class="information-2">
                <h2>Tenemos los <span>mejores</span> planes y ofertas</h2>
                <p>
                    Los mejores precios los tenemos nosotros.
                </p>
                
                <div class="img-content">
                    <img src="./images/sec-1.jpg" alt="">
                    <img src="./images/sec-2.jpg" alt="">
                    <img src="./images/sec-3.jpg" alt="">
                </div>
            </div>
        </div>
    </section>

    <section class="contact container">
        <h2>Comentarios</h2> 
       
        <div class="contacto-bg"></div>

        <form class="formulario">
            <div class="campo">
                <label class="campo__label" for="nombre">Nombre</label>
                <input 
                    class="campo__field"
                    type="text" 
                    placeholder="Tu Nombre" 
                    id="nombre"
                >
            </div>
            <div class="campo">
                <label class="campo__label" for="email">E-mail</label>
                <input 
                    class="campo__field"
                    type="email" 
                    placeholder="Tu E-mail" 
                    id="email"
                >
            </div>
            <div class="campo">
                <label class="campo__label" for="mensaje">Mensaje</label>
                <textarea 
                    class="campo__field campo__field--textarea"
                    id="mensaje"
                ></textarea>
            </div>

           
                <input type="submit" value="Enviar">
            
      

        </form>
       
    </section>

<script src="./js/script.js"></script>
<script src="./js/script1.js"></script>
        

    <footer class="footer">
        <div class="footer-content container">
            <div class="link">
                <h3>Terminos y condiciones</h3>
                <ul>
                    <li><a href="#">Devoluciones</a></li>
                    <li><a href="#">Cambios de boleto</a></li>
                    <li><a href="#">Pagos con Tarjeta</a></li>
                    <li><a href="facturacion.html">Facturacion</a></li>
                </ul>
            </div>
            <div class="link">
                <h3>Visitanos en redes sociales</h3>
                <ul>
                    <li><a href="#">Instagram</a></li>
                    <li><a href="#">Facebook</a></li>
                    <li><a href="#">X</a></li>
                    <li><a href="#">WhatsApp</a></li>
                </ul>
            </div>
            <div class="link">
                <h3>Recientes</h3>
                <ul>
                    <li><a href="#">Los mejores destinos en Mexico</a></li>
                    <li><a href="#">Destinos que manejamos</a></li>
                    <li><a href="#">Atracciones en Mazatlan</a></li>
                    <li><a href="#">Boletos de Avion</a></li>
                </ul>
            </div>
        </div>
    </footer>
</body>
</html>