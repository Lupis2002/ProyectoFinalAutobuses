<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="./css/stylesRegPas.css">
    <title>Asientos</title>
</head>

<body>
    <br>
    <div class="container">
        <form id="formulario" action="datosPasajerosCDMX.php" method="post">
            <div class="user-details" id="cantidadBoletos">
                <div class="input-box">
                    <span class="details">Numero de boletos</span>
                    <select name="numBoletos" id="numBoletos">
                        <option value="0">0</option>
                        <option value="1">1</option>
                        <option value="2">2</option>
                        <option value="3">3</option>
                    </select>
                </div>
                <div class="input-box">
                    <span class="details">Salida</span>
                    <input type="date" name="salida" id="salida" required>
                </div>
                <div class="input-box">
                    <span class="details">Regreso</span>
                    <input type="date" name="regreso" id="regreso" required>
                </div>
                <div class="input-box">
                    <span class="details">Destino</span>
                    <input type="text" name="destino" id="destino" value="CIUDAD DE MEXICO" readonly>
                </div>
                <br><br>
            </div>
            <!------------------------------------------->
            <h2>Selecciones sus asientos</h2>
            <ol id="seats-container"></ol>
            <br>
            <h2>Datos de los pasajeros</h2>
            <div id="camposPasajeros"></div>
            <br>
            <div class="button">
                <input type="submit" name="siguiente" value="SIGUIENTE">
            </div>
        </form>

        <script>
            document.getElementById('numBoletos').addEventListener('change', function () {
                var numBoletos = parseInt(this.value);
                var camposPasajeros = document.getElementById('camposPasajeros');
                var asientosHTML = '';

                camposPasajeros.innerHTML = '';

                for (var i = 1; i <= numBoletos; i++) {
                    var div = document.createElement('div');
                    div.innerHTML = `
                        <h3>Pasajero ${i}</h3>
                        <div class="user-details" id="camposUsuario">
                            <div class="input-box">
                                <span class="details">Nombre Completo</span>
                                <input type="text" name="nombre${i}" id="nombre${i}" required>
                            </div>
                            <div class="input-box">
                                <span class="details">Asiento</span>
                                <input type="text" name="asiento${i}" class="asiento-checkbox" readonly>
                            </div>
                            <div class="input-box">
                                <span class="details">Categoria</span>
                                <input type="text" name="categoria${i}" id="categoria${i}" value="ADULTO" readonly>
                            </div>
                            <div class="input-box">
                                <span class="details">Precio</span>
                                <input type="text" name="precio${i}" id="precio${i}" value="$55.00" readonly>
                            </div>
                        </div>
                    `;
                    camposPasajeros.appendChild(div);
                }

                var xhr = new XMLHttpRequest();
                xhr.open("GET", "asientosCDMX.php", true);
                xhr.onreadystatechange = function () {
                    if (xhr.readyState == 4 && xhr.status == 200) {
                        var asientosOcupados = JSON.parse(xhr.responseText);

                        for (var i = 1; i <= 6; i++) {
                            asientosHTML += '<li><ol class="seats">';
                            for (var j = 1; j <= 4; j++) {
                                var asiento = i + String.fromCharCode(64 + j);
                                var ocupado = asientosOcupados.indexOf(asiento) !== -1;

                                asientosHTML += `
                                    <li class="seat ${ocupado ? 'occupied' : ''}">
                                        <input type="checkbox" name="asiento[]" value="${asiento}" id="${asiento}" ${ocupado ? 'disabled' : ''} />
                                        <label for="${asiento}" ${ocupado ? 'style="color: red;"' : ''}>${asiento}</label>
                                    </li>
                                `;
                            }
                            asientosHTML += '</ol></li>';
                        }
                        document.getElementById('seats-container').innerHTML = asientosHTML;
                    }
                };
                xhr.send();
            });
        </script>
    </div>
</body>

</html>
