<?php
    $conex=mysqli_connect("localhost","root","","basefinalbuses");
    //$mysqli = new mysqli("localhost","root","","test_db");
?>