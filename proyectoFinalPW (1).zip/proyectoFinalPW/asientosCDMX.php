<?php
// Conexión a la base de datos (reemplaza estos valores con tus propias credenciales)
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "basefinalbuses";

// Crear conexión
$conn = new mysqli($servername, $username, $password, $dbname);

// Verificar conexión
if ($conn->connect_error) {
    die("Conexión fallida: " . $conn->connect_error);
}

// Consulta para obtener los asientos ocupados desde la base de datos
$sql = "SELECT num_asiento FROM asientoscdmx WHERE estado = 'O'";
$result = $conn->query($sql);

$asientosOcupados = array();

if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        $asientosOcupados[] = $row['num_asiento'];
    }
}

// Cerrar conexión
$conn->close();

// Devolver los datos como JSON
echo json_encode($asientosOcupados);

?>
