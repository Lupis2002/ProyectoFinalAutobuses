<?php
require("db_conn.php");

$sql="SELECT *FROM destinos";
$query=mysqli_query($conn,$sql);

?>
<!DOCTYPE html>
<html>
<head>
	<title>Create</title>
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
    <link rel="stylesheet" href="./css/styleListaUsuario.css">
</head>
<body>
	<div class="container">
		<div class="box">
			<h4 class="display-4 text-center">Lista de Viajes</h4><br>
			<table class="table table-striped">
			  <thead>
			    <tr>
			      <th scope="col">#</th>
				  <th scope="col">Desitno</th>
			    </tr>
			  </thead>
			  <tbody>
			  <?php while ($row = mysqli_fetch_array($query)): ?>
                    <tr>
                        <th><?= $row['destino_id'] ?></th>
						<th><?= $row['nombre'] ?></th>
                        <th><a href="delete_viaje.php?id_viaje=<?= $row['destino_id'] ?>" class="viajes-table--delete" >Eliminar</a></th>
                    </tr>
                <?php endwhile; ?>
			  
			  </tbody>
			</table>
			
			<div class="link-right">
				
                <a href="admin.php" class="link-primary">Pagina Principal</a>
			</div>
		</div>
	</div>
</body>
</html>