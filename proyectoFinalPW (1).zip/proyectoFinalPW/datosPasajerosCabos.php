<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="./css/stylesDatosPasajero.css">
    <title>Detalles del Viaje</title>
    <script src="https://www.paypal.com/sdk/js?client-id=ARMN3K9HBSCA5ioY5BSjJS6VZpIb56pHkzOpR0M8Am_3IEqzQiTwwozZFLbFQn8U6Dmpu936bFoyMJhK&currency=MXN"></script>
</head>
<body>

<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "basefinalbuses";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Conexión fallida: " . $conn->connect_error);
}

$salida = $_POST["salida"];
$regreso = $_POST["regreso"];
$destino = $_POST["destino"];
$numPasajeros = count($_POST["asiento"]);
$total = 0;

echo "<script>";
echo "var asientosOcupados = {};";
echo "</script>";

for ($i = 1; $i <= $numPasajeros; $i++) {
    $nombre = $_POST["nombre$i"];
    $asiento = $_POST["asiento"][$i - 1];
    $categoria = "ADULTO";
    $precio = 55.00;

    $sqlQuery = "SELECT estado FROM asientoscabos WHERE num_asiento = '$asiento'";
    $result = $conn->query($sqlQuery);
    $estadoAsiento = ($result->num_rows > 0) ? $result->fetch_assoc()['estado'] : '';

    echo "<script>asientosOcupados['$asiento'] = '$estadoAsiento';</script>";

    if ($estadoAsiento === 'O') {
        echo "SELECCIONE OTRO ASIENTO POR FAVOR";
        break;
    } else {
        $sql = "INSERT INTO pasajeroscabos (nombre, categoria, salida, regreso, precio, asiento, asiento_id, destino_id) VALUES ";
        $sql .= "('$nombre', '$categoria', '$salida', '$regreso', $precio, '$asiento', '1', '2')";

        $sql2 = "UPDATE asientoscabos SET estado = 'O' WHERE num_asiento = '$asiento'";
        $conn->query($sql2);

        if ($conn->query($sql) !== TRUE) {
            echo "Error al insertar datos: " . $conn->error;
        }
        $total += $precio;
    }
}

echo "</script>";

echo "<h2>Detalles del Viaje</h2>";
echo "<table>";
echo "<tr><th>Salida</th><td>$salida</td></tr>";
echo "<tr><th>Regreso</th><td>$regreso</td></tr>";
echo "<tr><th>Destino</th><td>$destino</td></tr>";
echo "</table>";

echo "<h2>Detalles de los Pasajeros</h2>";
echo "<table>";
echo "<tr><th>Nombre</th><th>Asiento</th><th>Categoría</th><th>Precio</th></tr>";
for ($i = 1; $i <= $numPasajeros; $i++) {
    $nombre = $_POST["nombre$i"];
    $asiento = $_POST["asiento"][$i - 1];
    echo "<tr><td>$nombre</td><td>$asiento</td><td>ADULTO</td><td>$55.00</td></tr>";
}
echo "</table>";
echo "<h2>Total del Viaje</h2>";
echo "<p>Total: $total MXN</p>";
echo "<br>";
echo "<h2>PAGUE CON</h2>";
echo "<div id='paypal-button-container' style='max-width: 250px;'></div>";

$conn->close();
?>

<script>
    paypal.Buttons({
        style: {
            color: 'blue',
            shape: 'pill',
            label: 'pay'
        },
        createOrder: function (data, actions) {
            return actions.order.create({
                purchase_units: [{
                    amount: {
                        value: <?php echo $total; ?>
                    }
                }]
            });
        },

        onApprove: function (data, actions) {
             actions.order.capture().then(function (detalles) {
                window.location.href = "boleto.php?" +
                "salida=" + detallesBoleto.salida +
                "&regreso=" + detallesBoleto.regreso +
                "&destino=" + detallesBoleto.destino +
                "&numPasajeros=" + detallesBoleto.numPasajeros +
                "&total=" + detallesBoleto.total +
                "&nombre=" + detallesBoleto.nombre +
                "&asiento=" + detallesBoleto.asiento;
            });
        },

        onCancel: function (data) {
            alert("Pago Cancelado");
        }
    }).render('#paypal-button-container');

    var detallesBoleto = {
    salida: '<?php echo $salida; ?>',
    regreso: '<?php echo $regreso; ?>',
    destino: '<?php echo $destino; ?>',
    numPasajeros: <?php echo $numPasajeros; ?>,
    total: <?php echo $total; ?>,
    nombre: '<?php echo $nombre; ?>',
    asiento: '<?php echo $asiento; ?>'
    }

</script>

</body>
</html>
