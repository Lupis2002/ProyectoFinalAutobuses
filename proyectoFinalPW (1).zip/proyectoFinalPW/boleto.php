<?php
require('fpdf.php');

// Obtén los datos del boleto de la URL
$salida = isset($_GET['salida']) ? $_GET['salida'] : '';
$regreso = isset($_GET['regreso']) ? $_GET['regreso'] : '';
$destino = isset($_GET['destino']) ? $_GET['destino'] : '';
$numPasajeros = isset($_GET['numPasajeros']) ? $_GET['numPasajeros'] : '';
$total = isset($_GET['total']) ? $_GET['total'] : '';
$nombre = isset($_GET['nombre']) ? $_GET['nombre'] : '';
$asiento = isset($_GET['asiento']) ? $_GET['asiento'] : '';

// Crear instancia de FPDF
$pdf = new FPDF();
$pdf->AddPage();

// Estilo del título
$pdf->SetFont('Arial', 'B', 16);
$pdf->SetTextColor(0, 102, 204); // Color azul
$pdf->Cell(0, 10, '¡Disfrute su viaje!', 0, 1, 'C');

// Estilo para los detalles del viaje
$pdf->SetFont('Arial', 'I', 12);
$pdf->SetTextColor(0, 0, 0); // Restaurar color negro
$pdf->Ln(10);
$pdf->Cell(0, 10, 'Detalles del Viaje', 0, 1, 'L');
$pdf->Cell(40, 10, 'Salida:', 0);
$pdf->Cell(0, 10, $salida, 0, 1);
$pdf->Cell(40, 10, 'Regreso:', 0);
$pdf->Cell(0, 10, $regreso, 0, 1);
$pdf->Cell(40, 10, 'Destino:', 0);
$pdf->Cell(0, 10, $destino, 0, 1);

// Estilo para los detalles de los pasajeros
$pdf->Ln(10);
$pdf->SetFont('Arial', 'U', 12);
$pdf->Cell(0, 10, 'Detalles de los Pasajeros', 0, 1, 'L');
$pdf->SetFont('Arial', '', 12);
$pdf->Cell(40, 10, 'Nombre', 1);
$pdf->Cell(40, 10, 'Asiento', 1);
$pdf->Cell(40, 10, 'Categoría', 1);
$pdf->Cell(40, 10, 'Precio', 1);
$pdf->Ln();
$pdf->Cell(40, 10, $nombre, 1);
$pdf->Cell(40, 10, $asiento, 1);
$pdf->Cell(40, 10, 'ADULTO', 1);
$pdf->Cell(40, 10, '$55.00', 1);
$pdf->Ln();

// Estilo para el total del viaje
$pdf->Ln(10);
$pdf->SetFont('Arial', 'B', 12);
$pdf->Cell(0, 10, 'Total del Viaje', 0, 1, 'L');
$pdf->Cell(0, 10, 'Total: ' . $total . ' MXN', 0, 1, 'L');

// Salida del PDF
$pdf->Output();
?>
